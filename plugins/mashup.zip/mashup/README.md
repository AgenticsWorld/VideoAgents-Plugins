# mashup — 混剪配画团队

**给讲述音频配现成素材画面,不生成一帧视频。** 用户提供 MP3 与对应文稿,
流程把文稿切成语义拍、逐拍设计镜头节奏,检索 YouTube/CC0 素材站的现成素材,
下载切片、拼接封装,**声轨就是用户原来那个 MP3**(零重编码)。
生成成本 → 检索与带宽成本。

与近亲 `audio-to-video` 插件的差异:

| | audio-to-video | 本插件(mashup) |
|---|---|---|
| 画面来源 | 图/视频生成(成本大头) | **检索现成素材**(YouTube 主通道 + Pexels/Pixabay 兜底) |
| 美术底座 | 必建(prompt 机检硬要求) | 不建;**保留 p0–p2 世界观作参考数据**(选意象/定检索语言) |
| 切分约束 | 整数秒 ∈[4,14](生成模型 --duration 逼的) | **拍/镜两层**:拍=句 ∈[1,20]s;镜长无上限、硬下限 0.5s |
| 交付公差 | ±1s(模型交付公差) | **零公差**(帧数按累计取整,现成素材想切多准切多准) |
| 新增风险轴 | — | **素材版权**(用户签字自担,台账强制登记)与**水印**(一票否决) |

母带纪律两者相同:母带即成片声轨、ffprobe 实测为唯一时长事实源、封装 `-c:a copy`、
严禁 `-shortest`、累计漂移恒 0。

---

## v2 节奏与语义方法论(2026-08-06,源于摸底反馈)

摸底测试的两个病根:3–5s 均拍导致**无节奏感**;按字面名词配画(「事情」→刷油漆)
导致**无共鸣**。v2 的解法固化为 shot-designer 的四步纪律:

1. **找信息焦点**:「就是自己喜欢的事情」重点在**「喜欢」**不在「事情」——焦点是
   情绪重心,不是语法宾语。
2. **定对应模式**(文画对应两逻辑):
   - **literal(一致)**:文字与画面讲同一个事——说曹操,画面就是曹操。1 镜,可长镜。
   - **render(相辅相成)**:文字与画面各承担不同信息——「喜欢的事」无画面可直接
     对应,用**人的状态**渲染(做事时的笑脸/投入);一个画面渲染力度不够就
     **群像多镜快切**(2–6 镜,0.8–2.5s/镜),**节奏感来源于此**。
   - 逐拍在 `shot_list.json` 的 `beat_design` 声明 mode+focus,机检硬卡。
3. **选意象,主题前瞻**:先通读全稿与世界观参考,意象服务**全片主题**——选熟悉、
   有共鸣、必要时带点「离经叛道」张力的主体(早餐摊夫妻/酒吧歌手/纹身师/画师),
   拒绝无共鸣的字面匹配。
4. **切镜定节奏**:镜带绝对 t_in/t_out 铺满所属拍,直给拍慢、渲染拍快,长短交替
   跟信息密度走,严禁全片镜长趋同。

**时间结构**:拍(beat,aligner 按句切,时长事实)⊃ 镜(shot,designer 拍内细分)。
1 镜 = 1 组不变,零漂移数学不变(帧数按绝对时刻累计取整,与镜长不齐无关)。

**世界观参考**:p0–p2 正常运行(文稿即文本输入,短文即单批;g2/H1 人签仍跳过,
世界观随 MH1 一并阅看)。用途:主题基调定意象共鸣方向;**文化圈定检索语言**——
中文语境搜中文词、日本文化搜日文词,普适意象用英文;CC0 素材站恒英文。

## ⚠️ 安装前必读:前置要求

| 要求 | 说明 |
|---|---|
| **VideoAgents 宿主自带** `modules/footage.py` + `code/check_footage.py` | 插件纯声明式(§10.4),工具链随宿主发布;旧版宿主装包不报错,**以第一个节点 mx0-ingest 的自检结论为准**。v2 需拍/镜两层口径的 check_footage(检查 5 名为 `beat_span_in_range`) |
| **yt-dlp 可用** | `pipx install yt-dlp`(或 brew);2025.11+ 版本另需 **node**(JS runtime),缺则部分 YouTube 视频 403 |
| **ffmpeg / ffprobe 可用** | `brew install ffmpeg` |
| **至少一个 agent 引擎** | `footage-curator` 必须派给**带视觉能力**的引擎(要看帧选片) |
| Pexels/Pixabay Key(可选) | CC0 兜底通道;`PEXELS_API_KEY`/`PIXABAY_API_KEY` 环境变量或 `data/.videoagents/footageconfig.json`。不配也能跑,只是没有素材站兜底 |

装完先跑:`python3 modules/footage.py doctor`(自检外部命令与检索连通性)。

## 安装

1. ⚙️ 设置 → 高级 → **插件** → 上传 `mashup-<版本>.zip`(或整目录复制进 `plugins/`)
2. 安装后**默认停用**,在「插件」页启用
3. 确认卡片显示 7 个 agent、workflow 路径,errors 为空

## 流程

```
p0–p2 剧情理解与世界圣经(文稿即文本输入;参考数据,g2 人签跳过)──┐
mx0 音频立项与分镜  audio-ingest(工具链自检+实测+停顿+sha256)      │
                    → transcript-aligner(一句一拍,吸附停顿,盖章)   │
                    → shot-designer(焦点→模式→意象→拍内切镜)◄──────┘
                    └─ gm0 [MH1 时间轴与分镜签字] ★基线,含节奏设计与版权责任自担
mx1 检索与选片      for_each 主题簇: footage-scout(元数据检索,零流量,
                      语言照 prompt,渲染簇逐组换主体)
                    → footage-curator(360p 预览逐帧核验;literal 看所指、
                      render 看人的状态讲 focus;定 rough 区间,登记台账)
                    └─ gm1 [MH2 选片确认] — 分镜预览页看选片帧,组注释调检索意图
mx2 下载与切片      for_each 组: clip-cutter(1080p 区间下载→零公差精剪归一;
                      镜时长取 shot_list 绝对 t_in/t_out)  ∥全并发
mx3 剪辑封装        10-editing/edit(footage.py concat+mux,母带 -c:a copy)
                    → subtitle(逐拍直转 SRT,字幕跟句不跟镜) → thumbnail
mx4 终审            mashup-qa(15 项机检+按 mode 分口径语义抽检+水印复查+台账终核)
                    ∥ visual-qa ∥ content-safety ∥ copyright(report_only)
                    └─ gm3 [MH3 成片签字] — 阅看 unknown license 清单
```

## 核心机制

**成本阶梯**(素材只在确认后才花高价流量):
search 元数据(零流量)→ 360p 预览+抽帧拼图(几 MB)→ 1080p 区间下载(几十 MB,
前后垫 3s 关键帧余量)。同一源视频服务整簇多镜,下载缓存复用。

**零公差时间轴**:文稿按字数比例估时+吸附停顿切成拍(无缝隙覆盖
`[0, master_duration_s]`),镜在拍内铺满、帧数按**累计取整**
`round(t_out×fps)−round(t_in×fps)`,整条时间轴数学上不可能漂——快切短镜再多
也不影响该数学;`check_footage.py` 四段 15 项机检兜底,
`--stamp` 盖章机制与 av 插件同宗(audio_map 改版即时间轴过期)。

**水印一票否决**:摸底实测**约 1/3 候选因水印/台标被毙,是第一大淘汰因**
(Videohive/Envato/Nimia/CinemaStock 的预览片伪装成正常结果混在搜索里)。
scout 按标题特征降权标注,curator 逐帧盯四角与网格浅纹,mashup-qa 终审全片复查。

**版权口径(用户决策,2026-08-06)**:不过滤 license,责任由用户 MH1 签字自担;
流程强制**如实登记**——`mashup/sources.json` 逐源记
provider/id/url/title/uploader/license/used_by,机检 `sources_registered` 兜底,
unknown license 清单在 MH3 签字时呈给用户。`11-qa/copyright` 转 report_only。

## 在分镜预览页编辑与调整(设计目标)

`shot_list.json` 按标准 schema 落正史(1 镜 = 1 组;v2 增量键 t_in/t_out/beat_id/
beat_design,页面忽略不认识的键),分镜预览页零改动可用:

| 页面元素 | 混剪语义 | 调整方式 |
|---|---|---|
| 场次分块 | 主题簇(一簇共用源视频;渲染拍群像天然同簇) | ✏️ 修改 → 总制片回派 shot-designer |
| 每组 📄 Prompt | 焦点/模式 + 画面需求 + 检索意图(含语言) | 只读查看 |
| 每组 📝 组注释 | **调整检索意图的入口**:注释注入 video_prompt,scout 重跑必重读 | 页面直接编辑 |
| 组锚点图(keyframes) | curator 的选片帧,MH2 签字凭据 | 看图打回 |
| 组卡片段(clips) | 切好的素材片段 | 播放核验 |
| ✏️ 修改按钮 | 换画面/换区间/改节奏等自由指令 | 发给总制片按语义回派 |

改**拍边界**的指令会回派 transcript-aligner 重切并重盖章(拍时间轴是一体的);
改**拍内节奏**(镜数/快慢)回派 shot-designer 重切镜,拍不动、不需重盖章;
换画面/换素材只动对应簇/组,时间轴不动,不需重签 MH1。

## 团队

**新增 6 个**(类别 `16-mashup`「混剪配画」)+ 1 个 QA:

| Agent | 职责 | 主要产物 |
|---|---|---|
| `audio-ingest` | 工具链自检+母带入册+实测(只测不改) | `mashup/audio_map.json` |
| `transcript-aligner` | 一句一拍切语义时间轴,吸附停顿,盖章 | `mashup/beat_track.json` |
| `shot-designer` | 焦点→模式→意象→拍内切镜定节奏,聚簇,定检索语言 | `directing/{ep}/shot_list.json` 等 |
| `footage-scout` ∥ | 多通道元数据检索(语言照 prompt),零流量出候选 | `mashup/candidates/*.json` |
| `footage-curator` 👁 | 逐帧核验选片(按 mode 分口径),定 rough 区间,登记台账 | `mashup/picks.json`、`sources.json` |
| `clip-cutter` ∥ | 区间下载+零公差精剪归一 | `assets/clips/{ep}/grpNNN.mp4` |
| `11-qa/mashup-qa` ∥ | 终审:机检全量+按 mode 语义抽检+水印复查+台账终核 | `qa/reports/{ep}/mashup.json` |

(∥=stateless 可并发;👁=须带视觉能力引擎)
**复用内置零改动**:`10-editing/edit`/`subtitle`/`thumbnail`、
`11-qa/visual-qa`/`content-safety`/`copyright`/`logic-qa`,
以及主流程 p0–p2 全部工位(01-story/02-worldbuilding,产参考数据)。
刻意不复用 `08-video-gen/*` 与 `06-art/*`(prompt 机检链对检索流程不适用)。

## 用法(插件已启用后)

1. **放素材**:MP3 放 `refs/audio/`,文稿放 `refs/`
2. **点单**给总制片:

```
启动 mashup 混剪流程:音频 refs/audio/qingxing.mp3,文稿 refs/qingxing.txt。
先跑 p0–p2 出世界观参考,并行 mx0 摄入对齐,
再逐拍分镜设计,出时间轴与节奏基线给我签 MH1。
```

或 CLI:

```bash
python3 services/runtime/dispatch.py "00-orchestration/workflow-orchestrator" \
  "启动 mashup 混剪流程:音频 refs/audio/qingxing.mp3,文稿 refs/qingxing.txt" \
  --project my-mashup
```

## 自检命令

```bash
python3 modules/footage.py doctor                                        # 装完先跑
python3 code/check_footage.py --project <slug> --ep ep01                 # 自动判阶段
python3 code/check_footage.py --project <slug> --ep ep01 --require final # 成片终审
python3 services/runtime/dagcheck.py --project <slug> --strict
```

## v2 不做

ASR 强对齐(字数比例估时+停顿吸附已够,beat_track 留 `source` 字段将来换)、
多集(一个 MP3 = 一个项目 = ep01)、BGM/音效叠加(破坏零重编码)、片头片尾、
画质增强/调色统一(素材异源色调不一是混剪美学预期)、专属预览页(分镜预览页够用)、
转场特效(快切节奏靠硬切,不靠叠化)。

## 建议

第一次跑 v2 用 **60–90 秒**、抽象与具象混合的口播稿摸节奏(纯具象稿全片 literal,
体现不出渲染拍快切)。渲染拍的群像检索比 v1 多几倍搜索量(逐镜换主体),属预期;
最可能卡住的两处:群像某镜主体搜不到(scout 换主体重搜或降级素材站,不许硬凑
同主体)、yt-dlp 403(装 node,或 `yt-dlp -U` 升级)。
