# audio-drama — 有声剧 / 播客制作插件

把现有世界观、分集剧本和声音资产，转成可发布的有声剧或播客。它不是 `audio-to-video` 的反向复制：本插件的最终产品是音频母带，视频不是必需品。

## 适用输入

- 小说、世界圣经或已经拆好的分集剧本
- `story/episodes/epNN/screenplay.md`
- `story/episodes/epNN/dialogue.md`
- `story/episodes/epNN/narration.md`
- `bible/characters/*/voice.json`
- `assets/audio/voice/casting.json`
- 已有角色语音、旁白、BGM、音效和环境声

## 流程

```text
剧本/小说
  ↓
ad0 有声化改编：旁白、对白、音效、音乐、停连
  ↓
ad1 声音导演：角色声线、情绪、录音/合成清单
  ↓
ad2 配音 + 旁白 + BGM + 音效 + 环境声
  ↓
ad3 混音、响度、片头片尾
  ↓
ad4 音频 QA / 版权 / 安全
  ↓
ad5 播客发布包装
```

## 输出目录

插件工作文件只写项目的 `audio-drama/` 命名空间：

```text
data/projects/<slug>/audio-drama/
├── scripts/       # 有声化脚本、cue sheet
├── casting/       # 角色声音与情绪指导
├── voices/        # 语音生成清单和分轨索引
├── mix/           # 混音报告、响度报告、母带版本
└── publish/       # 封面、简介、元数据、发布包
```

人工确认后，才允许把最终文件复制到项目既有的 `publish/audio/`。

## 与 tothemoon 的关系

`tothemoon` 已有 `screenplay.md`、`dialogue.md`、`narration.md`、`casting.json` 和第一集播客成品，因此可以从 `ad0` 的“读取已有有声化材料”模式开始，不必重新拆整部剧本。

## 边界

- 插件是纯声明式的，不携带新的 Python/FFmpeg 可执行代码。
- 配音、混音、音频 QA 优先复用主工程已有 Agent。
- 不改写正史 Bible；新增有声剧专用标注写入 `audio-drama/`。
- 片头片尾作为版本化音频资产管理，不在每次混音时临时生成。

